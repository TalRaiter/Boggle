import itertools
from ex11_utils import *
from GUI import *
from Game import *
import tkinter as tk
import pygame


ANNOUNCMENT_NOT_A_WORD = "This Is Not A Word We Like"
ANNOUNCMENT_YOU_ALREADY_FOUND_THIS = "You Already Found This Word"


class Connector:

   def __init__(self):
       self.gui = Boogle_Gui()
       self.game = Game()
       self.gui.enterbutton.config(command=self.enter_pressed)
       self.gui.start_button.config(command=self.start_pressed)
       self.gui.play_again_button.config(command=self.play_again)
       self.gui.end_game_button.config(command=self.end)

   def start_pressed(self):
       for i in range(len(self.gui.button_lst)):
           for j in range(len(self.gui.button_lst[0])):
               self.gui.button_lst[i][j].config(text=str(self.game.board[i][j]), state= "normal")
       self.gui.start_button.destroy()
       self.gui.play_music()
       self.gui.countdown()

   def enter_pressed(self):
       """
       what do we do when enter is pressed:
       1. we take the word path
       2. check if itws valid -> if no we announce it and start over
       3. turn it to the word
       4. check if we didn't already found this word:
       -> if we found it already we announce it and start over
       5. we update the score and add the word to words list
       6. we insert the word to the gui words list
       7. we insert the correct score to the gui
       8.after all we are cleaning - buttons color, pressed buttons list, enabling al buttons
       """
       word_paths = self.gui.pressed_button_loc_lst
       if is_valid_path(self.game.board, word_paths, self.game.words):
           word = path_to_word(word_paths, self.game.board)
           if word not in self.game.found_words_lst:
               self.game.found_words_lst.append(word)
               self.game.enter_is_pressed(word_paths) # update the score and add to words list
               self.gui.word_list.insert(tk.END, word + "," + " ")
               score = self.game.score
               self.gui.scoreLabel.config(text="SCORE: " + str(score))
           else:
               self.gui.not_valid_word(ANNOUNCMENT_YOU_ALREADY_FOUND_THIS)
       else:
           self.gui.not_valid_word(ANNOUNCMENT_NOT_A_WORD)

       self.gui.enable_all_table_buttons()
       self.gui.color_all_buttons(BG_COLOR)
       self.gui.pressed_button_lst = []
       self.gui.pressed_button_loc_lst = []

   def run(self):
       self.gui.run()

   def play_again(self):
       self.gui.end_game_window.withdraw()
       self.gui.main_window.destroy()
       boggle = Connector()
       boggle.run()
       # start the game again

   def end(self):
       self.gui.main_window.destroy()


if __name__ == "__main__":
    boggle = Connector()
    boggle.run()
