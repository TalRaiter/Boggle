from typing import List, Tuple, Iterable, Optional
import itertools
from queue import PriorityQueue

Board = List[List[str]]
Path = List[Tuple[int, int]]


def is_loc_in_board(board: Board, path: Path):
    for loc in path:
        loc_y = loc[0]
        loc_x = loc[1]
        if loc_y < 0 or loc_y >= len(board):
            return False
        if loc_x < 0 or loc_x >= len(board[0]):
            return False
    return True


def is_only_once(path):
    word_counts = {}
    for loc in path:
        if loc in word_counts:
            word_counts[loc] += 1
        else:
            word_counts[loc] = 1

    for word in word_counts.keys():
        if word_counts[word] > 1:
            return False
    return True


def is_valid_path(board: Board, path: Path, words: Iterable[str]) -> Optional[str]:
    """
    :param board:
    :param path:
    :param words:
    :return: checks if path in board index, checks if each  tuple mention once,
    check if path is legal by the game rules, check if path is a word in dict.
    """
    if is_only_once(path) == False:
        return None
    new_word = ""
    all_y = []
    all_x = []
    if not is_loc_in_board(board, path):
        return None
    for loc in path:
        all_y.append(loc[0])
        all_x.append(loc[1])

    for i in range(len(all_y) - 1):
        if abs(all_y[i] - all_y[i + 1]) != 0 and abs(all_y[i] - all_y[i + 1]) != 1:
            return None
    for i in range(len(all_x) - 1):
        if abs(all_x[i] - all_x[i + 1]) != 0 and abs(all_x[i] - all_x[i + 1]) != 1:
            return None
    new_word = path_to_word(path, board)
    if new_word in words:
        return new_word
    else:
        return None


def all_coordinates_in_board(board: Board):
    """
    :param board:
    :return: all the cells in the board in tuples of (row,column)
    """
    coordinates = []
    for i in range(len(board)):
        for j in range(len(board[0])):
            coordinates.append((i,j))
    return coordinates


def subgroups_in_specific_size(group, size):
    """
    :param group: the big group
    :param size: size asked for subgroups
    :return: all subgroups possible in the size that has been asked, include order difference
    """
    return [list(sub) for sub in itertools.permutations(group, size)]


def find_legitimate_paths(n: int, board: Board, words: List[str], chars_set: set, row: int, col: int, curr_path: List, legitimate_paths: List):
    if row < 0 or row >= len(board) or col < 0 or col >= len(board[0]):
        return
    if (row, col) in curr_path:
        return
    curr_path.append((row, col))
    curr_word = path_to_word(curr_path, board)
    if len(curr_path) > n:
        curr_path.remove((row, col))
        return
    if not is_char_in_words_lst(curr_word,chars_set):
        curr_path.remove((row, col))
        return
    if len(curr_path) == n and is_valid_path(board, curr_path, words) and curr_path not in legitimate_paths:
        legitimate_paths.append(curr_path[:])
    for r in range(row-1,row+2):
        for c in range(col-1,col+2):
            if c == col and r == row:
                continue
            find_legitimate_paths(n, board, words, chars_set, r, c,  curr_path, legitimate_paths)
    curr_path.remove((row, col))


def find_length_n_paths_helper(n, board, words, charset):
    if n > len(board) * len(board[0]):
        return []
    if n == 0:
        return []
    legitimate_paths = []
    for r in range(len(board)):
        for c in range(len(board[0])):
            curr_path = []
            find_legitimate_paths(n,board,words,charset,r,c,curr_path,legitimate_paths)
    return legitimate_paths


def find_length_n_paths(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    """
    :param n: path length
    :param board:
    :param words:
    :return: list of lists of tuples - all path in the size of n that create a word from words
    """
    if n > len(board) * len(board[0]):
        return []
    if n == 0:
        return []
    legitimate_paths = []
    charset = set_of_lst_chars(words,board)
    for r in range(len(board)):
        for c in range(len(board[0])):
            curr_path = []
            find_legitimate_paths(n,board,words,charset,r,c,curr_path,legitimate_paths)
    return legitimate_paths


def start_with_letter_in_board(words_lst,board):
    letter_in_board = []
    words_start_with_letter = []
    for row in range(len(board)):
        for letter in range(len(board[0])):
            if board[row][letter] not in letter_in_board:
                letter_in_board.append(board[row][letter])
    letter_in_board = tuple(letter_in_board)
    for word in words_lst:
        if word.startswith(letter_in_board):
            words_start_with_letter.append(word)
    return words_start_with_letter


def set_of_lst_chars(words_lst, board):
    charset = set()
    words_start_with_ltr_on_board = start_with_letter_in_board(words_lst,board)
    for word in words_start_with_ltr_on_board:
        for char in range(1,len(word)+1):
            charset.add(word[:char])
    return charset


def is_char_in_words_lst(char: str, charset: set):
    """
    :param charset:
    :param char: a string of words we are building
    :param words:
    :return:
    """
    if char in charset:
        return True
    return False

def all_words_in_length_n(words,n) -> List[str]:
    """
    :param words:
    :param n: word length
    :return: all words from words in the size of n
    """
    if len(max(words, key=len)) < n:
        return []

    return [word for word in words if len(word) == n]


def convert_3d_to_2d(lst):
    """
    :param lst: 3d LIST
    :return: 2D LIST
    """
    return [elem for sublist in lst for elem in sublist]


def find_length_n_words(n: int, board: Board, words: Iterable[str]) -> List[Path]:
    """

    :param n: word length
    :param board:
    :param words:
    :return: all paths that vaild for words in n length
    """
    if len(max(words, key=len)) < n:
        return []
    # board_cordinates = all_coordinates_in_board(board)
    # all_path_combinations = \
    #     convert_3d_to_2d([subgroups_in_specific_size(board_cordinates,size) for size in range(1,n+1)])
    word_len_n = all_words_in_length_n(words,n)
    legitimate_paths = []
    for n in range(1,n+1):
        paths = find_length_n_paths(n,board,word_len_n)
        if paths not in legitimate_paths:
            legitimate_paths.append(paths)
    legitimate_paths = convert_3d_to_2d(legitimate_paths)
    return legitimate_paths


def path_to_word(path, board):
    """
    :param path:
    :param board:
    :return: the word in the board that is given from the path
    """
    new_word = ""
    for loc in path:
        loc_y = loc[0]
        loc_x = loc[1]
        new_word += board[loc_y][loc_x]
    return new_word


def max_score_paths(board: Board, words: Iterable[str]) -> List[Path]:
    """
    :param board:
    :param words:
    :return: the words pathes that can give the higher score
    """
    dict_word_count = {}
    all_values = []
    # words = start_with_letter_in_board(words, board)
    charset = set_of_lst_chars(words,board)
    max_ln = len(board) * len(board[0])
    max_word_ln = len(max(words,key=len))
    # words.sort()
    max_word = min(max_word_ln, max_ln)
    for n in range(1, max_word+1):  # the max len of a word is the len of the board
        all_path = find_length_n_paths_helper(n, board,words, charset)  # for every optional len, will find all the paths
        for path in all_path:  # for every path we will find the word it represent and the score it gets
            new_word = path_to_word(path, board)
            score = n ** 2
            if new_word in dict_word_count:  # dict that the key is the word and the value is the path and the scor
                if dict_word_count[new_word][1] <= score:  # if the word in the dict and the score is higher- change the path and the score
                    dict_word_count[new_word] = [path]
                    dict_word_count[new_word] += [score]
            else:
                dict_word_count[new_word] = [path]
                dict_word_count[new_word] += [score]
    for value in dict_word_count.values():
        all_values.append(value[0]) # return only the path that gives the hights rank
    return all_values


