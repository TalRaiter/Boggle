import tkinter as tk
from PIL import Image
import pygame

BG_COLOR = "#FEF2F3"
BG_FRAME = "#FDDADB"
TB_COLOR = "#EDEDED"
BTON_COLOR = "#FBFCE3"
SELECTED_COLOR = "#FBEE9D"
FONT = "Comic Sans MS"

class Boogle_Gui:

    def __init__(self):
        """
        top frame = where title is
        left frame = where board and pressed words is
        right frame = timer, score, start, play again
        """
        root = tk.Tk()
        self.main_window = root
        root.title("Boggle")
        root.resizable(False,False)
        root.geometry("1200x700")
        root.config(bg= "#FEF2F3")

        #title frame:
        self.top_frame = tk.Frame(root, width= 900, height=100, bg=BG_COLOR,
                                  highlightbackground=BG_COLOR,highlightthickness=10)
        self.top_frame.pack(side= tk.TOP,fill=tk.BOTH,expand= True)
        self.title_photo()

        # decorations
        self.decorations("barbie.gif", 0.15, 0)
        self.decorations("barbie2.gif", 0.85, 0)

        # left frame
        self.left_frame = tk.Frame(root, width= 600, height=900, bg=BG_FRAME,
                                   highlightbackground=BG_COLOR,highlightthickness=10)
        self.left_frame.pack(side=tk.LEFT,fill=tk.BOTH,expand=True)
        self.frame_config(self.left_frame)

        # right frame
        self.right_frame = tk.Frame(root, width=350, height=700, bg=BG_FRAME,
                                    highlightbackground=BG_COLOR,highlightthickness=10)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        self.frame_config(self.right_frame)

        # button table frame
        self.button_lst = []
        self.pressed_button_lst = []
        self.pressed_button_loc_lst = []
        self.table_frame = tk.Frame(self.left_frame, width= 500, height=500, bg=TB_COLOR)
        self.table_frame.place(rely=0.05,relx=0.1)
        self.table()
        self.disable_table_buttons()

        # timer:
        self.timeleft = 180
        self.timeLabel = tk.Label(self.right_frame, text='Time Left: 180', font= (FONT, 30), bg= BG_FRAME)
        self.timeLabel.grid(row=0, column=0, sticky="NSEW")

        # score:
        self.score = 0
        self.scoreLabel = tk.Label(self.right_frame,text = "SCORE: " + str(self.score),font= (FONT,30), bg=BG_FRAME)
        self.scoreLabel.grid(row=1, column=0, sticky="NSEW")

        # enter:
        self.enterLabel = tk.Label(self.left_frame, bg=BG_FRAME)
        self.enterLabel.place(relx=0.27,rely=0.9)
        self.enter_button()

        # start:
        self.startlabel = tk.Label(self.right_frame, bg=BG_FRAME)
        self.startlabel.grid(row=2, column=0, sticky="NSEW")
        self.start_button()

        # words list:
        self.wordslabel = tk.Label(self.right_frame, bg= BG_FRAME)
        self.wordslabel.grid(row=3, column=0, sticky="NSEW")
        self.list_of_words()



        #end game window
        self.end_game_window = tk.Toplevel(self.main_window, bg=BG_FRAME)
        self.end_game_window.resizable(False,False)
        self.end_game_window.geometry("600x600")
        self.end_game_window.title("End Game")
        self.frame_config(self.end_game_window)
            # endgame title:
        self.label = tk.Label(self.end_game_window, text="Time's up! Do you want to play again?", font= (FONT,20), bg=BG_FRAME)
        self.label.grid(row=0,column=0)
            # endgame picture

        usimg = tk.PhotoImage(file="us.gif")
        us_label = tk.Label(self.end_game_window, image=usimg, bg=BG_FRAME)
        us_label.image = usimg
        us_label.grid(row=1,column=0)
            #engame buttons
        self.buttons_frame = tk.Frame(self.end_game_window, bg=BG_FRAME)
        self.buttons_frame.grid(row=3, column=0)
        self.play_again_button = tk.Button(self.buttons_frame, text="Play Again", bg=BG_COLOR, width=20, height=3)
        self.play_again_button.pack(side=tk.RIGHT)
        self.end_game_button = tk.Button(self.buttons_frame, text="End Game", bg=BG_COLOR, width=20, height=3)
        self.end_game_button.pack(side=tk.LEFT)
        self.end_game_window.withdraw()


    def decorations(self, file,relx,rely):
        barbie1img = tk.PhotoImage(file=file)
        barbie_1_label = tk.Label(self.top_frame, image= barbie1img, bg=BG_COLOR)
        barbie_1_label.image = barbie1img
        barbie_1_label.place(relx=relx,rely=rely, anchor="n")


    def frame_config(self, frame):
        frame.columnconfigure(0, weight=1, minsize=50)
        frame.rowconfigure(0, weight=1, minsize=50)
        frame.rowconfigure(1, weight=1, minsize=50)
        frame.rowconfigure(2, weight=1, minsize=50)
        frame.rowconfigure(3, weight=1, minsize=50)


    def start_button(self):
        self.start_button = tk.Button(self.startlabel, text="START", font=(FONT, 30), bg=BG_COLOR)
        self.start_button.pack()


    def list_of_words(self):
        self.word_list = tk.Text(self.wordslabel)
        self.word_list.config(width=35, height=3, font=(FONT, 20), bg=TB_COLOR)
        self.word_list.pack()


    def table(self):
        for i in range(4):
            button_row = []
            for j in range(4):
                button = tk.Button(self.table_frame, text=' ')
                button.grid(row=i, column=j)
                button.config(bg=BG_COLOR, width=14, height=7)
                button.config(command= lambda row=i, col=j: self.pressed_button(row, col))
                button_row.append(button)
            self.button_lst.append(button_row)


    def disable_table_buttons(self):
        for i in range(len(self.button_lst)):
            for j in range(len(self.button_lst[0])):
                self.button_lst[i][j].config(state="disable")


    def enter_button(self):
        self.enterbutton = tk.Button(self.enterLabel, text="ENTER", font=(FONT, 14), bg=BG_COLOR, width=20,height=1)
        self.enterbutton.pack()


    def stop_music(self):
        pygame.mixer.music.stop()


    def play_music(self):
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load("boggle_song.mp3")
        pygame.mixer.music.play()


    def title_photo(self):
        root = self.top_frame
        image = Image.open("BOGGLE_TITLE_REAL_resized.gif")
        image.thumbnail((250, 250))
        photo = tk.PhotoImage(file="BOGGLE_TITLE_REAL_resized.gif")
        label = tk.Label(root, image=photo, bg=BG_COLOR)
        label.image = photo
        label.place(relx=0.5, rely=0, anchor="n")


    def enable_all_table_buttons_except_pressed(self):
        """
        enabling all letter buttons. exepeted from pressed ones
        :return:
        """
        for i in range(4):
            for j in range(4):
                if self.button_lst[i][j] not in self.pressed_button_lst:
                    self.button_lst[i][j].config(bg=BTON_COLOR,state="normal")


    def enable_all_table_buttons(self):
        for i in range(4):
            for j in range(4):
                self.button_lst[i][j].config(bg=BTON_COLOR, state="normal")


    def color_all_buttons(self, color):
        for i in range(4):
            for j in range(4):
                self.button_lst[i][j].config(bg= color)


    def pressed_button(self,row,col):
        """
        while button is pressed and enter hasn't been pressed yet, enable= true only for buttons that are valid to use.
        :return:
        """
        self.pressed_button_loc_lst.append((row,col))
        curr_pressed = self.button_lst[row][col]
        curr_pressed.config(bg= SELECTED_COLOR, state="disable")
        self.pressed_button_lst.append(curr_pressed)
        self.enable_all_table_buttons_except_pressed()
        for r in range(4):
            for c in range(4):
                if not (r in range(row - 1, row + 2) and c in range(col - 1, col + 2)) and \
                        self.button_lst[r][c] not in self.pressed_button_lst:
                    self.button_lst[r][c].config(bg= BG_COLOR,state='disable')


    def not_valid_word(self, announcment):
        announcement = tk.Label(self.main_window, text=announcment, font=(FONT, 50), bg= "#9DFBF4")
        announcement.place(relx=0.5, rely=0.5, anchor="center")
        self.main_window.after(1000, lambda: announcement.destroy())


    def countdown(self):
        # if a game is in play
        if self.timeleft > 0:
            # decrement the timer.
            self.timeleft -= 1
            # update the time left label
            self.timeLabel.config(text="Time left: " + str(self.timeleft))
            # run the function again after 1 second.
            self.timeLabel.after(1000, self.countdown)
        if self.timeleft == 0:
            self.timeLabel.config(text="Time's up!")
            self.enterLabel.destroy()
            self.disable_table_buttons()
            self.end_game_window.deiconify()
            self.stop_music()


    def run(self):
        self.main_window.mainloop()


