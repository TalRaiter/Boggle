from boggle_board_randomizer import *
from ex11_utils import *

def open_boogle_dict():
    with open('boggle_dict.txt', 'r') as fp:
        lines = fp.readlines()
    WORDS = []
    for line in lines:
        WORDS.append(line.strip())
    return WORDS


WORDS = open_boogle_dict()


class Game:

    def __init__(self):
        self.board = randomize_board()
        self.score = 0
        self.pressed_buttons_loc_lst = []
        self.found_words_lst = []
        self.words = WORDS

    def score_update(self,path):
        """
        word loc: list of tuples.every tuple is a location on the board
        updates score
        """
        new_score = (len(path)) ** 2
        self.score = self.score + new_score

    def update_pressed_button_loc(self, path):
        """
        :param path: the curr loc  of button on board ha been pressed
        :return:
        """
        self.pressed_buttons_loc_lst.append(path)

    def update_found_words_lst(self,path):
        """
        :param path: pressed word path
        updates the words list
        """
        word = path_to_word(path , self.board)
        self.found_words_lst.append(word)

    def enter_is_pressed(self, path):
        """
        path: list of tuples of locations
        return: update_score and updating the words list
        """
        if is_valid_path(self.board, path, self.words):
            self.score_update(path)
            self.update_found_words_lst(path)

    def game_is_over(self):
        """
        return: bool if we found all the words that are in the board
        """
        all_words_in_board = max_score_paths(self.board, self.words)
        if len(all_words_in_board) == len(self.found_words_lst):
            return True
        else:
            return False

    def get_found_words_lst(self):
        return self.found_words_lst

    def get_board(self):
        return self.board

    def get_score(self):
        return self.score

    def run_game(self):
        pass
